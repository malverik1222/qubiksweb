import os
from datetime import timedelta

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'qubiks-secret-key-2024'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///qubiks.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Telegram Bot
    TELEGRAM_TOKEN = '8069632830:AAEFp1BwoBw_Hexk1uZg-doioeNUcV5snjs'
    ADMIN_ID = 7316381327
    
    # Prices
    SUBSCRIPTION_PRICE = 2500
    USDT_RATE = 86.0
    
    # API
    SEARCH_API_TOKEN = "ZN4MTYFos0ubBgsO3psBHfhLOQkMVNo"
    SEARCH_API_URL = "https://infosearch54321.xyz/api"
    
    # Upload
    UPLOAD_FOLDER = 'static/uploads'
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
    
    # Session
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)
    
    # Server settings for production
    SERVER_NAME = os.environ.get('SERVER_NAME')  # ваш-логин.pythonanywhere.com