from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, send_file
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
import json
import os
from datetime import datetime
import requests
import asyncio
import threading

from config import Config
from database import db, User, Payment, SearchQuery, Withdrawal
from search_api import VectorBot

app = Flask(__name__)
app.config.from_object(Config)

# Инициализация
db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Пожалуйста, войдите в систему'

vector_bot = VectorBot()

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Создание таблиц при запуске
with app.app_context():
    db.create_all()
    print("✅ Database tables created/verified")

# Главная страница
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

# Страница входа
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        telegram_id = request.form.get('telegram_id')
        user = User.query.filter_by(telegram_id=telegram_id).first()
        
        if user and not user.is_banned:
            login_user(user)
            user.last_login = datetime.utcnow()
            db.session.commit()
            
            flash('Успешный вход!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Пользователь не найден или заблокирован', 'error')
    
    return render_template('login.html')

# Выход
@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('index'))

# Дашборд
@app.route('/dashboard')
@login_required
def dashboard():
    stats = {
        'searches_today': SearchQuery.query.filter(
            SearchQuery.user_id == current_user.id,
            SearchQuery.created_at >= datetime.today().date()
        ).count(),
        'total_searches': SearchQuery.query.filter_by(user_id=current_user.id).count(),
        'balance': current_user.balance
    }
    return render_template('dashboard.html', stats=stats, user=current_user)

# Поиск
@app.route('/search', methods=['GET', 'POST'])
@login_required
def search():
    if not current_user.has_access:
        flash('Для доступа к поиску необходимо приобрести подписку', 'warning')
        return redirect(url_for('payment'))
    
    if request.method == 'POST':
        query = request.form.get('query')
        if not query:
            flash('Введите запрос для поиска', 'error')
            return redirect(url_for('search'))
        
        # Сохраняем запрос
        search_record = SearchQuery(
            user_id=current_user.id,
            query=query,
            query_type=vector_bot.query_analyzer.detect_query_type(query)[0],
            created_at=datetime.utcnow()
        )
        db.session.add(search_record)
        db.session.commit()
        
        # Выполняем поиск в отдельном потоке
        def perform_search():
            try:
                result = asyncio.run(vector_bot.search_data(query))
                search_record.results = json.dumps(result, ensure_ascii=False)
                db.session.commit()
            except Exception as e:
                app.logger.error(f"Search error: {e}")
        
        thread = threading.Thread(target=perform_search)
        thread.start()
        
        return render_template('search_results.html', 
                             query=query, 
                             search_id=search_record.id,
                             query_type=search_record.query_type)
    
    return render_template('search.html')

# Результаты поиска (AJAX)
@app.route('/search/results/<int:search_id>')
@login_required
def search_results(search_id):
    search_record = SearchQuery.query.get_or_404(search_id)
    
    if search_record.user_id != current_user.id:
        return jsonify({'error': 'Доступ запрещен'}), 403
    
    if search_record.results:
        results = json.loads(search_record.results)
        formatted = vector_bot.format_beautiful_result(results, search_record.query, False)
        return jsonify({'completed': True, 'results': formatted})
    else:
        return jsonify({'completed': False, 'message': 'Поиск еще выполняется...'})

# Оплата
@app.route('/payment')
@login_required
def payment():
    usdt_amount = round(Config.SUBSCRIPTION_PRICE / Config.USDT_RATE, 2)
    return render_template('payment.html', 
                         price=Config.SUBSCRIPTION_PRICE,
                         usdt_amount=usdt_amount,
                         usdt_rate=Config.USDT_RATE)

# Загрузка чека
@app.route('/upload_receipt', methods=['POST'])
@login_required
def upload_receipt():
    if 'receipt' not in request.files:
        flash('Файл не выбран', 'error')
        return redirect(url_for('payment'))
    
    file = request.files['receipt']
    if file.filename == '':
        flash('Файл не выбран', 'error')
        return redirect(url_for('payment'))
    
    if file:
        filename = f"receipt_{current_user.id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.jpg"
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        
        # Создаем запись о платеже
        payment = Payment(
            user_id=current_user.id,
            amount=Config.SUBSCRIPTION_PRICE,
            method='card',
            receipt_filename=filename,
            status='pending'
        )
        db.session.add(payment)
        db.session.commit()
        
        flash('Чек отправлен на проверку. Ожидайте подтверждения.', 'success')
        return redirect(url_for('dashboard'))

# Админ-панель
@app.route('/admin')
@login_required
def admin_panel():
    if current_user.telegram_id != Config.ADMIN_ID:
        flash('Доступ запрещен', 'error')
        return redirect(url_for('dashboard'))
    
    stats = {
        'total_users': User.query.count(),
        'active_users': User.query.filter_by(has_access=True).count(),
        'total_balance': db.session.query(db.func.sum(User.balance)).scalar() or 0,
        'pending_payments': Payment.query.filter_by(status='pending').count()
    }
    
    pending_payments = Payment.query.filter_by(status='pending').all()
    users = User.query.order_by(User.created_at.desc()).limit(10).all()
    
    return render_template('admin.html', 
                         stats=stats, 
                         pending_payments=pending_payments,
                         users=users)

# API для админа
@app.route('/admin/api/<action>', methods=['POST'])
@login_required
def admin_api(action):
    if current_user.telegram_id != Config.ADMIN_ID:
        return jsonify({'error': 'Доступ запрещен'}), 403
    
    data = request.get_json()
    
    if action == 'approve_payment':
        payment_id = data.get('payment_id')
        payment = Payment.query.get(payment_id)
        
        if payment:
            payment.status = 'approved'
            payment.processed_at = datetime.utcnow()
            
            user = User.query.get(payment.user_id)
            user.has_access = True
            
            db.session.commit()
            return jsonify({'success': True})
    
    elif action == 'reject_payment':
        payment_id = data.get('payment_id')
        payment = Payment.query.get(payment_id)
        
        if payment:
            payment.status = 'rejected'
            payment.processed_at = datetime.utcnow()
            db.session.commit()
            return jsonify({'success': True})
    
    return jsonify({'error': 'Неизвестное действие'}), 400

# Информация о доступе
@app.route('/info')
def info():
    domain = request.host_url.rstrip('/')
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Qubiks - Информация о доступе</title>
        <style>
            body {{ 
                font-family: Arial, sans-serif; 
                background: #0f172a; 
                color: white; 
                margin: 0; 
                padding: 2rem;
            }}
            .container {{ 
                max-width: 600px; 
                margin: 0 auto; 
                background: #1e293b; 
                padding: 2rem; 
                border-radius: 1rem; 
                border: 1px solid #334155;
            }}
            .logo {{ 
                text-align: center; 
                font-size: 2rem; 
                margin-bottom: 2rem; 
                color: #6366f1;
            }}
            .step {{ 
                background: #334155; 
                padding: 1rem; 
                margin: 1rem 0; 
                border-radius: 0.5rem; 
                border-left: 4px solid #6366f1;
            }}
            .url {{ 
                background: #475569; 
                padding: 0.5rem; 
                border-radius: 0.25rem; 
                font-family: monospace; 
                margin: 0.5rem 0;
            }}
            .btn {{ 
                background: #6366f1; 
                color: white; 
                padding: 1rem 2rem; 
                border: none; 
                border-radius: 0.5rem; 
                text-decoration: none; 
                display: inline-block; 
                margin: 0.5rem 0;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="logo">🔐 Qubiks</div>
            <h1>Информация о доступе</h1>
            
            <div class="step">
                <h3>📱 Шаг 1: Получите ваш ID в Telegram боте</h3>
                <p>Напишите боту команду: <strong>/id</strong></p>
                <p>Бот: @Qubiksbot</p>
            </div>
            
            <div class="step">
                <h3>🌐 Шаг 2: Откройте веб-интерфейс</h3>
                <p>Перейдите по ссылке:</p>
                <div class="url">{domain}</div>
                <a href="{domain}" class="btn">Открыть веб-интерфейс</a>
            </div>
            
            <div class="step">
                <h3>🔑 Шаг 3: Войдите в систему</h3>
                <p>Используйте ваш Telegram ID для входа</p>
            </div>
            
            <div class="step">
                <h3>🛠 Нужна помощь?</h3>
                <p>Telegram: @sledak_support</p>
            </div>
        </div>
    </body>
    </html>
    """

# API для бота
@app.route('/api/user/<int:telegram_id>')
def get_user_info(telegram_id):
    user = User.query.filter_by(telegram_id=telegram_id).first()
    if user:
        return jsonify({
            'id': user.id,
            'telegram_id': user.telegram_id,
            'username': user.username,
            'balance': user.balance,
            'has_access': user.has_access,
            'is_banned': user.is_banned
        })
    else:
        return jsonify({'error': 'User not found'}), 404

# Создание папки для загрузок
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])
    print(f"✅ Created upload folder: {app.config['UPLOAD_FOLDER']}")

if __name__ == '__main__':
    print("🚀 Starting Qubiks Web Application...")
    print("🌐 Web interface:", request.host_url if 'request' in locals() else "http://your-domain.com")
    print("📱 Info page: /info")
    print("🤖 Make sure Telegram bot is running separately")
    
    # Для продакшена используем waitress вместо debug сервера
    if os.environ.get('PRODUCTION'):
        from waitress import serve
        serve(app, host='0.0.0.0', port=5000)
    else:
        app.run(debug=True, host='0.0.0.0', port=5000)