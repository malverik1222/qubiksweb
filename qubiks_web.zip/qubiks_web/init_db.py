from app import app, db
from database import User, Payment, SearchQuery, Withdrawal

def init_database():
    with app.app_context():
        # Создаем все таблицы
        db.create_all()
        print("✅ База данных успешно создана!")
        
        # Проверяем таблицы
        tables = ['user', 'payment', 'search_query', 'withdrawal']
        for table in tables:
            try:
                result = db.engine.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table}'")
                if result.fetchone():
                    print(f"✅ Таблица {table} создана")
                else:
                    print(f"❌ Таблица {table} не создана")
            except Exception as e:
                print(f"❌ Ошибка проверки таблицы {table}: {e}")

if __name__ == '__main__':
    init_database()