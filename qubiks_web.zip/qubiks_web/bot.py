import telebot
from telebot import types
import sqlite3
import logging
import requests
from config import Config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

bot = telebot.TeleBot(Config.TELEGRAM_TOKEN)

# Домен веб-приложения (замените на ваш)
WEB_DOMAIN = "https://your-username.pythonanywhere.com"  # ИЗМЕНИТЕ НА ВАШ ДОМЕН

def get_db_connection():
    conn = sqlite3.connect('qubiks.db')
    conn.row_factory = sqlite3.Row
    return conn

def ensure_user(telegram_id, username, referrer_id=None):
    """Создает пользователя если не существует"""
    conn = get_db_connection()
    
    user = conn.execute(
        'SELECT * FROM user WHERE telegram_id = ?', (telegram_id,)
    ).fetchone()
    
    if not user:
        conn.execute('''
            INSERT INTO user (telegram_id, username, referrer_id, balance, has_access, is_banned, test_used)
            VALUES (?, ?, ?, 0, 0, 0, 0)
        ''', (telegram_id, username, referrer_id))
        conn.commit()
        logger.info(f"Created new user: {telegram_id} - @{username}")
    
    conn.close()

@bot.message_handler(commands=['start'])
def send_welcome(message):
    user_id = message.from_user.id
    username = message.from_user.username
    
    ref_id = None
    parts = message.text.split()
    if len(parts) > 1 and parts[1].startswith('ref_'):
        try:
            ref_id = int(parts[1][4:])
        except:
            ref_id = None
    
    ensure_user(user_id, username, ref_id)
    
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🌐 Открыть веб-интерфейс", url=WEB_DOMAIN))
    markup.add(types.InlineKeyboardButton("🛠 Поддержка", url="https://t.me/sledak_support"))
    markup.add(types.InlineKeyboardButton("🆔 Мой ID", callback_data="show_id"))
    
    bot.send_message(
        message.chat.id,
        f"👋 Добро пожаловать в *Qubiks*!\n\n"
        f"*Ваш ID для входа:* `{user_id}`\n\n"
        f"🌐 *Веб-интерфейс:* {WEB_DOMAIN}\n\n"
        f"⚠️ *Тестовый пробив отключен.*\n"
        f"Для демонстрации возможностей обратитесь в поддержку.\n\n"
        f"💡 *Команды бота:*\n"
        f"/id - показать ваш ID\n"
        f"/balance - проверить баланс\n"
        f"/web - ссылка на веб-интерфейс\n"
        f"/help - поддержка",
        reply_markup=markup,
        parse_mode='Markdown'
    )

@bot.message_handler(commands=['id'])
def send_user_id(message):
    user_id = message.from_user.id
    
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🌐 Открыть веб-интерфейс", url=WEB_DOMAIN))
    
    bot.send_message(
        message.chat.id,
        f"🆔 *Ваш данные для входа:*\n\n"
        f"*Telegram ID:* `{user_id}`\n\n"
        f"*Инструкция:*\n"
        f"1. Откройте веб-интерфейс\n"
        f"2. Введите ваш ID: `{user_id}`\n"
        f"3. Нажмите 'Войти в систему'",
        reply_markup=markup,
        parse_mode='Markdown'
    )

@bot.message_handler(commands=['web'])
def send_web_link(message):
    user_id = message.from_user.id
    
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🌐 Открыть Qubiks", url=WEB_DOMAIN))
    
    bot.send_message(
        message.chat.id,
        f"🌐 *Ссылка на веб-интерфейс*\n\n"
        f"*URL:* {WEB_DOMAIN}\n"
        f"*Ваш ID для входа:* `{user_id}`",
        reply_markup=markup,
        parse_mode='Markdown'
    )

@bot.message_handler(commands=['help', 'support'])
def send_help(message):
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("📞 Написать в поддержку", url="https://t.me/sledak_support"))
    markup.add(types.InlineKeyboardButton("🌐 Веб-интерфейс", url=WEB_DOMAIN))
    
    bot.send_message(
        message.chat.id,
        f"🛠 *Техническая поддержка Qubiks*\n\n"
        f"📞 *Поддержка:* @sledak_support\n\n"
        f"🌐 *Веб-интерфейс:* {WEB_DOMAIN}\n\n"
        f"💡 *Частые вопросы:*\n"
        f"• *Вход в систему:* используйте /id чтобы узнать ваш ID\n"
        f"• *Оплата:* через веб-интерфейс\n"
        f"• *Тестовый доступ:* обратитесь в поддержку\n\n"
        f"🔧 *Команды бота:*\n"
        f"/start - начать работу\n"
        f"/id - мой ID для входа\n" 
        f"/web - ссылка на веб-интерфейс\n"
        f"/balance - проверить баланс\n"
        f"/help - эта справка",
        reply_markup=markup,
        parse_mode='Markdown'
    )

@bot.message_handler(commands=['balance'])
def check_balance(message):
    user_id = message.from_user.id
    conn = get_db_connection()
    
    user = conn.execute(
        'SELECT balance, has_access FROM user WHERE telegram_id = ?', (user_id,)
    ).fetchone()
    
    if user:
        balance = user['balance']
        has_access = "✅ Активна" if user['has_access'] else "❌ Неактивна"
        
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("💳 Управление балансом", url=f"{WEB_DOMAIN}/payment"))
        
        bot.send_message(
            message.chat.id,
            f"💰 *Ваш аккаунт*\n\n"
            f"*Баланс:* {balance} ₽\n"
            f"*Подписка:* {has_access}\n\n"
            f"*Для управления:*\n"
            f"• Откройте веб-интерфейс\n"
            f"• Используйте ID: `{user_id}`",
            reply_markup=markup,
            parse_mode='Markdown'
        )
    else:
        bot.send_message(message.chat.id, "❌ Пользователь не найден. Используйте /start для регистрации.")
    
    conn.close()

@bot.callback_query_handler(func=lambda call: True)
def handle_callback(call):
    if call.data == "show_id":
        bot.answer_callback_query(call.id, f"Ваш ID: {call.from_user.id}\n\nИспользуйте его для входа на: {WEB_DOMAIN}", show_alert=True)
    elif call.data == "instructions":
        user_id = call.from_user.id
        bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text=f"📋 *Инструкция по входу*\n\n"
                 f"1. *Откройте веб-интерфейс:*\n"
                 f"   {WEB_DOMAIN}\n\n"
                 f"2. *Используйте для входа:*\n"
                 f"   ID: `{user_id}`\n\n"
                 f"3. *Если возникают проблемы:*\n"
                 f"   • Используйте команду /web для ссылки\n"
                 f"   • Обратитесь в поддержку /help",
            parse_mode='Markdown'
        )

def notify_admin(message):
    try:
        bot.send_message(Config.ADMIN_ID, message, parse_mode='Markdown')
    except Exception as e:
        logger.error(f"Failed to notify admin: {e}")

def notify_user(telegram_id, message):
    try:
        bot.send_message(telegram_id, message, parse_mode='Markdown')
    except Exception as e:
        logger.error(f"Failed to notify user {telegram_id}: {e}")

if __name__ == '__main__':
    logger.info("Starting Telegram bot...")
    
    try:
        conn = get_db_connection()
        conn.execute('''
            CREATE TABLE IF NOT EXISTS user (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_id BIGINT UNIQUE NOT NULL,
                username TEXT,
                email TEXT,
                balance INTEGER DEFAULT 0,
                has_access BOOLEAN DEFAULT 0,
                is_banned BOOLEAN DEFAULT 0,
                referrer_id INTEGER,
                test_used BOOLEAN DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_login DATETIME,
                password_hash TEXT,
                session_token TEXT
            )
        ''')
        conn.commit()
        conn.close()
        logger.info("Database tables created/verified")
    except Exception as e:
        logger.error(f"Database initialization error: {e}")
    
    notify_admin(f"🤖 *Бот Qubiks запущен!*\n\nВеб-интерфейс: {WEB_DOMAIN}")
    
    bot.infinity_polling()