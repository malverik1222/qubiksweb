import requests
import re
import logging
from typing import Dict, Any, List, Tuple, Optional

logger = logging.getLogger(__name__)

class QueryAnalyzer:
    """Анализатор типов запросов"""
    
    @staticmethod
    def detect_query_type(query: str) -> Tuple[str, str]:
        """Определяет тип запроса и возвращает (тип, иконка)"""
        query_clean = query.strip().lower()
        
        # 🚗 Поиск по авто
        if re.match(r'^[авекмнорстух]\d{3}[авекмнорстух]{2}\d{2,3}$', query_clean.replace(' ', '')):
            return "🚗 Поиск по гос. номеру", "🚗"
        elif re.match(r'^[a-hj-npr-z0-9]{17}$', query_clean.replace(' ', '').upper()):
            return "🚗 Поиск по VIN", "🚗"
        
        # 🌐 Поиск по контактным данным
        elif re.match(r'^7\d{10}$', re.sub(r'\D', '', query_clean)):
            return "📞 Поиск по телефону", "📞"
        elif '@' in query_clean:
            if query_clean.startswith('@'):
                return "✈️ Поиск по Telegram", "✈️"
            return "📧 Поиск по email", "📧"
        elif re.match(r'^[a-z0-9_]{3,20}$', query_clean):
            return "👤 Поиск по логину", "👤"
        
        # 🏛 Поиск по документам
        elif re.match(r'^\d{4}\s?\d{6}$', query_clean.replace(' ', '')):
            return "📘 Поиск по паспорту", "📘"
        elif re.match(r'^\d{10,12}$', query_clean.replace(' ', '')):
            return "📊 Поиск по ИНН", "📊"
        elif re.match(r'^\d{3}-\d{3}-\d{3}\s?\d{2}$', query_clean) or re.match(r'^\d{11}$', query_clean.replace(' ', '').replace('-', '')):
            return "📋 Поиск по СНИЛС", "📋"
        elif re.match(r'^\d{13}$', query_clean.replace(' ', '')):
            return "🏢 Поиск по ОГРН", "🏢"
        elif re.match(r'.*ссср.*|.*мю.*|.*№.*', query_clean):
            return "📜 Поиск по паспорту СССР", "📜"
        
        # 👤 Поиск по ФИО/имени
        elif re.search(r'[а-я]{3,}\s+[а-я]{3,}', query_clean):
            if re.search(r'\d{2}[\.\-\s]\d{2}[\.\-\s]?\d{4}', query_clean):
                return "👤 Поиск по ФИО и дате рождения", "👤"
            elif re.search(r'\d{4}', query_clean):
                return "👤 Поиск по ФИО и году рождения", "👤"
            elif re.search(r'москва|спб|санкт-петербург|новосибирск|екатеринбург', query_clean):
                return "👤 Поиск по ФИО и городу", "👤"
            else:
                return "👤 Поиск по ФИО", "👤"
        elif re.match(r'^[а-я]{3,}$', query_clean):
            return "👤 Поиск по имени", "👤"
        
        # 🔍 Неопределенный запрос
        else:
            return "🔍 Общий поиск", "🔍"

class VectorBot:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json'
        })
        self.timeout = 30
        self.api_token = "ZN4MTYFos0ubBgsO3psBHfhLOQkMVNo"
        self.base_url = "https://infosearch54321.xyz/api"
        self.query_analyzer = QueryAnalyzer()

    async def search_data(self, query: str):
        """Поиск данных через ваше API"""
        try:
            url = f"{self.base_url}/{self.api_token}/search/{requests.utils.quote(query)}"
            logger.info(f"Запрос к API: {url}")
            
            response = self.session.get(url, timeout=self.timeout)
            
            if response.status_code == 200:
                data = response.json()
                logger.info(f"Успешный ответ от API")
                return data
            else:
                return {"error": f"Ошибка API (статус {response.status_code})"}
                
        except Exception as e:
            return {"error": f"Ошибка: {str(e)}"}

    def format_beautiful_result(self, result: dict, query: str, is_test: bool = False) -> str:
        """Форматирует результаты поиска красиво"""
        try:
            if 'error' in result:
                return f"❌ *Ошибка поиска:* {result['error']}"
            
            if 'result' not in result or not result['result']:
                return "❌ *Данные не найдены*\n\nПо вашему запросу ничего не найдено в базах данных."
            
            # Определяем тип запроса
            query_type, query_icon = self.query_analyzer.detect_query_type(query)
            
            response = f"{query_icon} *{query_type.upper()}*\n*Запрос:* `{query}`\n\n"
            
            # Упрощенное форматирование для веб-версии
            if isinstance(result['result'], dict):
                entries = result['result']
            elif isinstance(result['result'], list):
                entries = {str(i): item for i, item in enumerate(result['result'])}
            else:
                return "❌ *Неверный формат данных от API*"
            
            # Форматируем основные данные
            for key, value in entries.items():
                if isinstance(value, dict):
                    response += f"**{key}:**\n"
                    for k, v in value.items():
                        if v and str(v).strip():
                            response += f"• *{k}:* {v}\n"
                    response += "\n"
            
            if is_test:
                response += "⚠️ *ЭТО ТЕСТОВЫЙ РЕЗУЛЬТАТ*\n*Данные частично скрыты* 🔒\n\n"
                response += "💎 *Приобретите подписку для полного доступа*"
            else:
                response += "✅ *ПОЛНЫЙ ДОСТУП*\n"
                response += "*Все данные отображены без ограничений*"
            
            return response
            
        except Exception as e:
            logger.error(f"Ошибка форматирования: {e}")
            return "❌ *Произошла ошибка при форматировании результатов*\n\nПопробуйте другой запрос."